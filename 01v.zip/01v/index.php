<?php
// Перенаправляем на страницу авторизации
header("Location: login.php");
exit;
?>